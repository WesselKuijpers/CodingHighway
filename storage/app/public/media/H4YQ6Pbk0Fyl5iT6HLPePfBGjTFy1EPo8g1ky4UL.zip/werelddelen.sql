/*SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';*/

CREATE SCHEMA IF NOT EXISTS `werelddelen` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `werelddelen` ;

-- -----------------------------------------------------
-- Table `werelddelen`.`werelddeel`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `werelddelen`.`werelddeel` ;

CREATE  TABLE IF NOT EXISTS `werelddelen`.`werelddeel` (
  `werelddeelid` CHAR(2) NOT NULL ,
  `werelddeel` VARCHAR(25) NULL ,
  PRIMARY KEY (`werelddeelid`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `werelddelen`.`land`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `werelddelen`.`land` ;

CREATE  TABLE IF NOT EXISTS `werelddelen`.`land` (
  `landid` CHAR(2) NOT NULL ,
  `land` VARCHAR(25) NULL ,
  `werelddeelid` CHAR(2) NOT NULL ,
  PRIMARY KEY (`landid`) ,
  INDEX `werelddeel_idx` (`werelddeelid` ASC) ,
  CONSTRAINT `werelddeel`
    FOREIGN KEY (`werelddeelid` )
    REFERENCES `werelddelen`.`werelddeel` (`werelddeelid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `werelddelen`.`stad`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `werelddelen`.`stad` ;

CREATE  TABLE IF NOT EXISTS `werelddelen`.`stad` (
  `stadid` CHAR(4) NOT NULL ,
  `stad` VARCHAR(25) NULL ,
  `landid` CHAR(2) NULL ,
  PRIMARY KEY (`stadid`) ,
  INDEX `landid_idx` (`landid` ASC) ,
  CONSTRAINT `landid`
    FOREIGN KEY (`landid` )
    REFERENCES `werelddelen`.`land` (`landid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

USE `werelddelen` ;

SET SQL_MODE = '';
GRANT USAGE ON *.* TO wereld;
 DROP USER wereld;
SET SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';
CREATE USER 'wereld' IDENTIFIED BY 'land';

GRANT SELECT ON TABLE `werelddelen`.* TO 'wereld';
GRANT SELECT, INSERT, TRIGGER ON TABLE `werelddelen`.* TO 'wereld';
GRANT SELECT, INSERT, TRIGGER, UPDATE, DELETE ON TABLE `werelddelen`.* TO 'wereld';

/*SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;*/

-- -----------------------------------------------------
-- Data for table `werelddelen`.`werelddeel`
-- -----------------------------------------------------
START TRANSACTION;
USE `werelddelen`;
INSERT INTO `werelddelen`.`werelddeel` (`werelddeelid`, `werelddeel`) VALUES ('af', 'Afrika');
INSERT INTO `werelddelen`.`werelddeel` (`werelddeelid`, `werelddeel`) VALUES ('eu', 'Europa');
INSERT INTO `werelddelen`.`werelddeel` (`werelddeelid`, `werelddeel`) VALUES ('az', 'Azie');

COMMIT;

-- -----------------------------------------------------
-- Data for table `werelddelen`.`land`
-- -----------------------------------------------------
START TRANSACTION;
USE `werelddelen`;
INSERT INTO `werelddelen`.`land` (`landid`, `land`, `werelddeelid`) VALUES ('fr', 'Frankrijk', 'eu');
INSERT INTO `werelddelen`.`land` (`landid`, `land`, `werelddeelid`) VALUES ('ne', 'Nederland', 'eu');
INSERT INTO `werelddelen`.`land` (`landid`, `land`, `werelddeelid`) VALUES ('ch', 'China', 'az');
INSERT INTO `werelddelen`.`land` (`landid`, `land`, `werelddeelid`) VALUES ('vi', 'Vietnam', 'az');
INSERT INTO `werelddelen`.`land` (`landid`, `land`, `werelddeelid`) VALUES ('ka', 'kampala', 'af');
INSERT INTO `werelddelen`.`land` (`landid`, `land`, `werelddeelid`) VALUES ('an', 'Angola', 'af');

COMMIT;

-- -----------------------------------------------------
-- Data for table `werelddelen`.`stad`
-- -----------------------------------------------------
START TRANSACTION;
USE `werelddelen`;
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('par', 'Parijs', 'fr');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('ver', 'Versailles', 'fr');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('avi', 'Avignon', 'fr');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('rtd', 'Rotterdam', 'ne');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('ein', 'Eindhoven', 'ne');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('hko', 'Hong Kong', 'ch');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('bej', 'Bejing', 'ch');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('hcm', 'Ho Chi Minstad', 'vi');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('kam', 'Kampala', 'oe');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('ent', 'Entebbe', 'oe');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('lua', 'Luanda', 'an');
INSERT INTO `werelddelen`.`stad` (`stadid`, `stad`, `landid`) VALUES ('cab', 'Cabinda', 'an');

COMMIT;

/*
-- De queries om de gegevens op te halen
-- Eerst het overzicht zelf, daarna de totalen per werelddeel
-- en daarna het eindtotaal

select werelddeel, land, stad from werelddeel
inner join land on werelddeel.werelddeelid =land.werelddeelid
inner join stad on land.landid = stad.landid;

select werelddeel, count(stad) as totaal from werelddeel
inner join land on werelddeel.werelddeelid =land.werelddeelid
inner join stad on land.landid = stad.landid
group by werelddeel;

select count(stad) as eindtotaal from werelddeel
inner join land on werelddeel.werelddeelid =land.werelddeelid
inner join stad on land.landid = stad.landid;

-- einde queries
*/
